static const char* fileMutexName = "fileMutex";
static const char* messageAmountSemaphoreName = "messageAmountSemaphore";
static const char* startSemaphoreName = "startSemaphoreName";
static const int messageSize = 20;